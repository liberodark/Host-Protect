package liberodark;

public class Constants {
	public static final String APP_NAME = "Protect Hosts";
}
