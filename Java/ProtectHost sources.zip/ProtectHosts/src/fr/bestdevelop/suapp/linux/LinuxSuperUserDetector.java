package fr.bestdevelop.suapp.linux;

import fr.bestdevelop.suapp.posix.PosixSuperUserDetector;

public class LinuxSuperUserDetector extends PosixSuperUserDetector {

}
