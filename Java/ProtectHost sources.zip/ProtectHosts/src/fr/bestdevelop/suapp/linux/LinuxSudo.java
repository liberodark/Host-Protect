package fr.bestdevelop.suapp.linux;

import fr.bestdevelop.suapp.posix.PosixSudo;

public class LinuxSudo extends PosixSudo {

}
