package fr.bestdevelop.suapp;

public interface ISuperUserDetector {
	public boolean isSuperUser();
}
