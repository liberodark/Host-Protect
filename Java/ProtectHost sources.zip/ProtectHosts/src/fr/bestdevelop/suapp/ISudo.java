package fr.bestdevelop.suapp;

public interface ISudo {
	public int sudo();
	public int sudo(String[] args);
}
